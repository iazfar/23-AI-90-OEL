#!/bin/bash
BASE_DIR="./lab_users"
ARCHIVE_DIR="./archives"

mkdir -p "$BASE_DIR" 
mkdir -p "$ARCHIVE_DIR"

create_workspace() {
    read -rp "Enter username: " username

    if [[ -z "$username" ]]; then
        echo -e "Error: Username cannot be empty.${NC}"
        return
    fi

    local workspace="$BASE_DIR/$username"

    if [[ -d "$workspace" ]]; then
        echo -e "Workspace already exists.${NC}"
        return
    fi

    mkdir -p "$workspace"/{docs,code,shared}

    chmod 700 "$workspace"
    chmod 700 "$workspace/docs" "$workspace/code"
    chmod 755 "$workspace/shared"

    echo -e "Workspace created at $workspace${NC}"
}

check_quota() {
    echo -e "\n=== Disk Usage Check ===${NC}"
    read -rp "Enter username: " username

    local workspace="$BASE_DIR/$username"

    if [[ ! -d "$workspace" ]]; then
        echo -e "Workspace not found.${NC}"
        return
    fi

    local size_kb=$(du -sk "$workspace" | awk '{print $1}')
    local size_mb=$((size_kb / 1024))

    echo -e "Usage:${size_mb} MB${NC}"

    if (( size_mb > 100 )); then
        echo -e "ARNING: Exceeded 100MB limit${NC}"
    else
        echo -e "Within limit${NC}"
    fi
}

search_files() {
    echo -e "\n=== Search Files ===${NC}"
    read -rp "Enter filename or extension: " pattern

    if [[ -z "$pattern" ]]; then
        echo -e "Empty input not allowed.${NC}"
        return
    fi

    if [[ "$pattern" == .* ]]; then
        pattern="*$pattern"
    fi

    echo -e "\nResults:\n"
    printf "%-50s %-10s %-20s\n" "FILE" "SIZE" "MODIFIED"
    printf "%-50s %-10s %-20s\n" "----" "----" "--------"

    local found=0

    while IFS= read -r file; do
        size=$(du -sh "$file" | awk '{print $1}')
        modified=$(date -r "$file" "+%Y-%m-%d %H:%M")

        printf "%-50s %-10s %-20s\n" "$file" "$size" "$modified"
        found=1
    done < <(find "$BASE_DIR" -type f -name "$pattern")

    if [[ $found -eq 0 ]]; then
        echo -e "No files found.${NC}"
    fi
}

archive_workspaces() {
    echo -e "\n=== Archive Workspaces (>60 days) ===${NC}"

    local found=0

    for workspace in "$BASE_DIR"/*; do
        [[ -d "$workspace" ]] || continue

        username=$(basename "$workspace")

        last_modified=$(find "$workspace" -type f -exec stat -c %Y {} \; 2>/dev/null | sort -n | tail -1)

        [[ -z "$last_modified" ]] && last_modified=0

        now=$(date +%s)
        days=$(( (now - last_modified) / 86400 ))

        if (( days >= 60 )); then
            found=1
            echo -e "\n$username inactive ($days days)${NC}"

            read -rp "Archive? (y/n): " choice
            if [[ "$choice" == "y" ]]; then
                tar -czf "$ARCHIVE_DIR/${username}.tar.gz" -C "$BASE_DIR" "$username"
                echo -e "rchived${NC}"
            fi
        fi
    done

    [[ $found -eq 0 ]] && echo -e "No old workspaces found.${NC}"
}

delete_workspace() {
    echo -e "\n=== Delete Workspace ===${NC}"
    read -rp "Enter username: " username

    workspace="$BASE_DIR/$username"

    if [[ ! -d "$workspace" ]]; then
        echo -e "Not found.${NC}"
        return
    fi

    read -rp "Are you sure? (y/n): " confirm
    if [[ "$confirm" == "y" ]]; then
        rm -rf "$workspace"
        echo -e "eleted${NC}"
    else
        echo "Cancelled."
    fi
}

while true; 
do
    echo -e "\n===== USER WORKSPACE MANAGER =====${NC}"
    echo "1. Create Workspace"
    echo "2. Check Disk Usage"
    echo "3. Search Files"
    echo "4. Archive Old Workspaces"
    echo "5. Delete Workspace"
    echo "6. Exit"

    read -rp "Choose option: " choice

    case $choice in
        1) create_workspace ;;
        2) check_quota ;;
        3) search_files ;;
        4) archive_workspaces ;;
        5) delete_workspace ;;
        6) echo "Goodbye"; exit ;;
        *) echo -e "${RED}Invalid option${NC}" ;;
    esac
done